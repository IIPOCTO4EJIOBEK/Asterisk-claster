/*!
 * Bootstrap-select v1.11.2 (http://silviomoreto.github.io/bootstrap-select)
 *
 * Copyright 2013-2016 bootstrap-select
 * Licensed under MIT (https://github.com/silviomoreto/bootstrap-select/blob/master/LICENSE)
 */

(function (root, factory) {
  if (typeof define === 'function' && define.amd) {
    // AMD. Register as an anonymous module unless amdModuleId is set
    define(["jquery"], function (a0) {
      return (factory(a0));
    });
  } else if (typeof exports === 'object') {
    // Node. Does not work with strict CommonJS, but
    // only CommonJS-like environments that support module.exports,
    // like Node.
    module.exports = factory(require("jquery"));
  } else {
    factory(jQuery);
  }
}(this, function (jQuery) {

(function ($) {
  $.fn.selectpicker.defaults = {
	noneSelectedText: 'No hay selección',
    noneResultsText: 'No hay resultados {0}',
    countSelectedText: function (numSelected, numTotal) {
      return (numSelected == 1) ? "{0} elemento seleccionado" : "{0} elementos seleccionados";
    },
    maxOptionsText: function (numAll, numGroup) {
      return [
        (numAll == 1) ? 'Límite alcanzado ({n} elemeto max)' : 'Límite alcanzado ({n} elementos max)',
        (numGroup == 1) ? 'Límite del grupo alcanzado ({n} elemento max)' : 'Límite del grupo alcanzado ({n} elementos max)'
      ];
    },
    selectAllText: 'Seleccionar Todo',
    deselectAllText: 'Desmarcar Todo',
    multipleSeparator: ', '
  };
})(jQuery);


}));
